var express = require('express');
var session = require('express-session');
const users = require('./routes/users.route');
const maingroup = require('./routes/maingroup.route');
const subgroup = require('./routes/subgroup.route');
const product = require('./routes/products.route');

var bodyparser = require('body-parser');

//----------------------- START MongoDB Confiuration ------------------------------------------
const mongoose = require('mongoose');

let dev_db_url = 'mongodb+srv://rk1:1@cluster0-cyfug.mongodb.net/sgthread?retryWrites=true';
const mongoDB = process.env.MONGODB_URI || dev_db_url;

mongoose.connect(mongoDB,{ useNewUrlParser: true });

mongoose.Promise = global.Promise;
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
//----------------------- END MongoDB Confiuration ------------------------------------------

//----------------------- START EXPRESS JS CODE ---------------------------------------------
var app = express();
app.use(bodyparser.json());
//-------- SESSION --------------------------------
app.use(session({secret: '/*-+#$ZXCVBBNM1234QWERTYUIOP567ASDFGHJKL890%^&!(){}[]<>'}));

//-------- CSS JAVASCRIPT IMAGES ------------------
app.use('/assets', express.static('assets'))

//------- EJS ---------------
app.set('view engine', 'ejs');

//------- ROUTING ----------
app.use('/users',users);
app.use('/maingroup',maingroup);
app.use('/subgroup',subgroup);
app.use('/product',product);

app.listen(3000, () => {
  console.log("Server Started ...........");
})
//----------------------- END EXPRESS JS CODE ---------------------------------------------