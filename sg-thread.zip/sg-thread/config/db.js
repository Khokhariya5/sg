const CONNECTION_URL = "mongodb+srv://rk1:1@cluster0-cyfug.mongodb.net/test?retryWrites=true";
const DATABASE_NAME = "kosad";

module.export = CONNECTION_URL
module.export = DATABASE_NAME
