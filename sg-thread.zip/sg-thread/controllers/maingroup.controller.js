const mainGroupmodel = require('../models/maingroup.model');
//Simple version, without validation or sanitation

exports.maingroup_get = function (req, res) {
    var session = req.session.UniqueID;

    if(session)
    {
        var data = {};
        mainGroupmodel.find({},(err,group) => {

            if(err){
                return res.render('maingroup',{ "maingroup": data});
            }     
            data = group
            return res.render('maingroup',{ "maingroup": data});
        });
    }
    else
    {
        return res.redirect('/users/login');
    }
};

exports.maingroup_post = function (req, res) {

    var session = req.session.UniqueID;

    if(!session)
    {
        return res.redirect('/users/login');
    }

    const { maingroupname } = req.body;
    if(maingroupname)
    {
        var MainGroup = new mainGroupmodel({
            groupname: maingroupname
        });
        
        MainGroup.save(function (err){
            if(err)
            { 
                console.log("MainGroup Saved Error !");
                return res.redirect('/maingroup');
            }
            
            console.log("MainGroup Saved Success !");
            return res.redirect('/maingroup');

        });

    }
    else
    {
        return res.redirect('/maingroup');
    }
    
};