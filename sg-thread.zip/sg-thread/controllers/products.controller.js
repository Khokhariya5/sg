const mainGroupmodel = require('../models/maingroup.model');
const productmodel = require('../models/product.model');

exports.products_add_get = function (req, res) {
    var session = req.session.UniqueID;

    if(session)
    {
        var maindata = {}

        mainGroupmodel.find({},(err,group) => {

            if(err){
                return res.render('addProduct',{ "maingroup": maindata});
            }
            maindata = group
            return res.render('addProduct',{ "maingroup": maindata});
        });
        
    }
    else
    {
        return res.redirect('/users/login');
    }
    
};

exports.products_add_post = function (req, res) {
    var session = req.session.UniqueID;

    if(!session)
    {
        return res.redirect('/users/login');
    }

    const { name,price,unit,min,desc,group,img1,img2,img3 } = req.body;

    var product = new productmodel({
        pname :name,
        price:price,
        unit:unit,
        min:min,
        desc:desc,
        maingroup : group,
        img1:img1,
        img2:img2,
        img3:img3
    });

    product.save(function (err){

        if(err)
        { 
            console.log("Product Saved Error !" + err);
            return res.redirect('/product/add');
        }
        
        console.log("Product Saved Success !");
        

    });
    return res.redirect('/product/add');
};