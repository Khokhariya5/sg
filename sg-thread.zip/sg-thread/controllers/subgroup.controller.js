const subGroupmodel = require('../models/subgroup.model');
const mainGroupmodel = require('../models/maingroup.model');

exports.sub_group_get = function (req, res) {
    
    var session = req.session.UniqueID;

    if(session)
    {
        var maindata = {}
        var subdata = {}

        subGroupmodel.find({},(err,group) => {
            if(!err){
                subdata = group
            }
        });
        mainGroupmodel.find({},(err,group) => {

            if(err){
                return res.render('subgroup',{ "maingroup": maindata,"subgroup": subdata});
            }
            maindata = group
            return res.render('subgroup',{ "maingroup": maindata,"subgroup": subdata});
        });
        
    }
    else
    {
        return res.redirect('/users/login');
    }

};

exports.sub_group_post = function (req, res) {
    var session = req.session.UniqueID;

    if(!session)
    {
        return res.redirect('/users/login');
    }

    const { subgroupname, maingroupname } = req.body;
    
    if(subgroupname && maingroupname)
    {
        console.log(req.body)
        var SubGroup = new subGroupmodel({
            groupname: subgroupname,
            maingroup: maingroupname
        });
        
        SubGroup.save(function (err){
            if(err)
            { 
                console.log("SubGroup Saved Error !" + err);
                return res.redirect('/subgroup');
            }
            
            console.log("SubGroup Saved Success !");
            return res.redirect('/subgroup');

        });

    }
    else
    {
        return res.redirect('/subgroup');
    }
};