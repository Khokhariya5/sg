const Users = require('../models/users.model');

//Simple version, without validation or sanitation
exports.login_get = function (req, res,next) {
  session = req.session.UniqueID  
  if(session)
  {
    return res.redirect('/maingroup')
  }
  
  res.render('login');
};

exports.login_post = function (req, res) {
  var responseData = {}

  if(req.body)
  {
    const {txtUsername,txtPassword} = req.body;

    if(txtUsername && txtPassword)
    {
      var query = {
          username : txtUsername,
          password : txtPassword
      }

      Users.findOne(query).exec(function(err, result) {
        if (err) {
          res.render('login');
        }

        if(result)
        {
          responseData = {
            flag: 1,
            message: "Login Success !"
          }
          req.session.UniqueID = query.username
          res.redirect('/maingroup')
        }
        else {
          responseData = {
            flag: 0,
            message: "Username or Password is Wrong !"
          }
          res.render('login');
        }
      });

    }
    else 
    {
      responseData = {
        flag: 101,
        message: "Please Enter Username And Password !"
      }
      res.render('login')
    }

  }
  else {
    responseData = {
      flag: -1,
      message: "Not Valid Request !"
    }
    res.render('login')
  }
};

exports.login_get_out = function (req, res) {
  req.session.destroy();
  res.render('login')
};