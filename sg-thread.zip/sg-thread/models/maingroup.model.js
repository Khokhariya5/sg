const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let MainGroupSchema = new Schema({
    groupname: {type: String, required: true},
    inserted: {type: Date, default: Date.now},
});

var mainGroupmodel = mongoose.model('maingroups', MainGroupSchema);
// Export the model
module.exports = mainGroupmodel;
