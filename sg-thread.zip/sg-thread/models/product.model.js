const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let ProductSchema = new Schema({
    pname: {type: String, required: true},
    unit: {type: String, required: true},
    price: {type: String, required: true},
    min: {type: String, required: true},
    desc: {type: String, required: true},
    maingroup: {type: Array, required: true},
    img1: {type: String, required: true},
    img2: {type: String, required: true},
    img3: {type: String, required: true},
    inserted: {type: Date, default: Date.now},
});

var productmodel = mongoose.model('products', ProductSchema);
// Export the model
module.exports = productmodel;
