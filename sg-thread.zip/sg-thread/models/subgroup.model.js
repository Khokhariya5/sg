const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let SubGroupSchema = new Schema({
    groupname: {type: String, required: true},
    maingroup:{type: Array, required:true},
    inserted: {type: Date, default: Date.now},
});

var subGroupmodel = mongoose.model('subgroups', SubGroupSchema);
// Export the model
module.exports = subGroupmodel;