const express = require('express');
const router = express.Router();
const maingroup_controller = require('../controllers/maingroup.controller');


var bodyparser = require('body-parser');
var urlencodedparser = bodyparser.urlencoded({ extended: false });

router.get('/', maingroup_controller.maingroup_get);

router.post('/insert', urlencodedparser, maingroup_controller.maingroup_post);

module.exports = router
