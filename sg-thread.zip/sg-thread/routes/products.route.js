const express = require('express');
const router = express.Router();
const products_controller = require('../controllers/products.controller');


var bodyparser = require('body-parser');
var urlencodedparser = bodyparser.urlencoded({ extended: false });

router.get('/add', products_controller.products_add_get);
router.post('/insert', urlencodedparser,products_controller.products_add_post);

module.exports = router
