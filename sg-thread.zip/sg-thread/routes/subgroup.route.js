const express = require('express');
const router = express.Router();
const subgroup_controller = require('../controllers/subgroup.controller');


var bodyparser = require('body-parser');
var urlencodedparser = bodyparser.urlencoded({ extended: false });

router.get('/', subgroup_controller.sub_group_get);

router.post('/insert', urlencodedparser,subgroup_controller.sub_group_post);

module.exports = router
