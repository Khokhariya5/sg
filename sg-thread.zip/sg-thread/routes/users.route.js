const express = require('express');
const router = express.Router();
const users_controller = require('../controllers/users.controller');
var bodyparser = require('body-parser');
var urlencodedparser = bodyparser.urlencoded({ extended: false });

router.get('/login', users_controller.login_get);

router.get('/logout', users_controller.login_get_out);

router.post('/login', urlencodedparser,users_controller.login_post);

module.exports = router
